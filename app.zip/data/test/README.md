To run unit tests: 

`cd app\data`

`python -m unittest`

To add tests:
- Add test files to the `test` directory
- Make sure your test class extends `unittest.TestCase`
- Name your test file following the pattern `test_*.py`